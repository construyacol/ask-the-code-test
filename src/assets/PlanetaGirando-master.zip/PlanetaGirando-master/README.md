# EJERCICIO CSS - CREANDO CON CSS A LA TIERRA GIRANDO

Codigo creado siguiendo el siguiente tutorial de EDTeam: 
https://www.youtube.com/watch?v=u4n3fgUzJcQ


![](https://i.imgur.com/mBhxU16.png)

